pub const T_USB: &str = "usb";
pub const T_WIFI: &str = "wifi";
pub const T_NET: &str = "net";
pub const T_CRYPTO: &str = "crypto";
pub const T_AUDIT: &str = "audit";
